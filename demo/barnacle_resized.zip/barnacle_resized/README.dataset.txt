# barnacle > 2024-12-28 2:37pm
https://universe.roboflow.com/dali-mef57/barnacle-iby18

Provided by a Roboflow user
License: CC BY 4.0

